package com.hsr.demo.application.controller.admin;

public class UserRegistration {
}
